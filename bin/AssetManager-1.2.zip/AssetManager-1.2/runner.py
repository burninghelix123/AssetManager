import os
os.system("setup.py install")
import AssetManager
from AssetManager import AssetManager
